package com.mycompany.rest;

import android.app.*;
import android.os.*;
import com.google.android.material.bottomnavigation.*;
import com.google.android.material.floatingactionbutton.*;
import android.graphics.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.frag_layout);
		
		/*getWindow().setStatusBarColor(Color.parseColor("#1f2633"));
		getWindow().setNavigationBarColor(Color.parseColor("#283140"));*/
    }
}
